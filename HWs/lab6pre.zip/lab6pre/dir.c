#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ext2fs/ext2_fs.h>

#define BLKSIZE 1024

// define shorter TYPES, save typing efforts
typedef struct ext2_group_desc  GD;
typedef struct ext2_super_block SUPER;
typedef struct ext2_inode       INODE;
typedef struct ext2_dir_entry_2 DIR;    // need this for new version of e2fs

GD    *gp;
SUPER *sp;
INODE *ip;
DIR   *dp;

char  *cp;
int fd;
int iblock;
char *disk = "mydisk";
char *rootblock;
char buf[BLKSIZE];
char dbuf[BLKSIZE];
char sbuf[256];

int dir()
{
  get_block(fd, 1, buf);
  sp = (SUPER *)buf;

  printf("check ext2 FS on %s :", disk);
  if (sp->s_magic != 0xEF53) {
    printf("NOT an EXT2 FS\n");
    exit(2);
  }
  else
    printf("YES\n");

  // read GD block at (first_data_block + 1)
  get_block(fd, 2, buf);
  gp = (GD *)buf;
  printf("********** GD info **********\n");
  printf("%d %d %d %d %d %d\n",
         gp->bg_block_bitmap,
         gp->bg_inode_bitmap,
         gp->bg_inode_table,
         gp->bg_free_blocks_count,
         gp->bg_free_inodes_count,
         gp->bg_used_dirs_count);

  iblock = gp->bg_inode_table;   // get inode start block#
  printf("inode_block=%d\n", iblock);
  //read first INODE block to get root inode #2
  get_block(fd, iblock, buf);
  ip = (INODE *)buf + 1; // '/'

  printf("****** root inode info ******\n");
  printf("mode=%4x ", ip->i_mode);
  printf("uid=%d  gid=%d\n", ip->i_uid, ip->i_gid);
  printf("size=%d\n", ip->i_size);
  printf("time=%s", ctime(&ip->i_ctime));
  printf("link=%d\n", ip->i_links_count);
  printf("i_block[0]=%d\n", ip->i_block[0]);
  rootblock = ip->i_block[0];
  printf("*****************************\n");

  // consider i_block[0] ONLY
  get_block(fd, ip->i_block[0], dbuf);
  dp = (DIR *)dbuf;
  cp = dbuf;
  printf("inode rec_len name_len name\n");
  printf("*****************************\n");
  while (cp < &dbuf[BLKSIZE])
  {
    strncpy(sbuf, dp->name, dp->name_len);
    sbuf[dp->name_len] = 0;

    printf("%5d %7d %8d %4s\n",
           dp->inode, dp->rec_len, dp->name_len, sbuf);
    cp += dp->rec_len;   // advance cp by rec_len BYTEs
    dp = (DIR *)cp;      // pull dp along to the next record
  }
}

int get_block(int fd, int blk, char buf[ ])
{
  //printf("get_block: fd=")
  lseek(fd, (long)blk * BLKSIZE, 0);
  read(fd, buf, BLKSIZE);
}

main(int argc, char *argv[])
{
  if (argc > 1)
    disk = argv[1];

  fd = open(disk, O_RDONLY);
  if (fd < 0) {
    printf("open %s failed\n", disk);
    exit(1);
  }

  dir();
}